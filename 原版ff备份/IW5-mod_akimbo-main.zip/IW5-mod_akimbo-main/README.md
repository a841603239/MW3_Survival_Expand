# Scuffed implication of akimbo for iw5-mod survival!

> [!IMPORTANT]
> Known Issues!
>
> The akimbo attachment will be visible for all weapons, but it will only function on those that support it.
>
> You can purchase the akimbo attachment again, even if you already own it.
>
> PP90M1 Akimbo has no reload sounds.

# 
This mod was made using [OAT](https://github.com/Laupetin/OpenAssetTools)!

I have included everything you need to build and work on the mod!

If you wish to improve this and want to update this version please message me on discord: `SadSlothXL`
#
### Supported Weapons:
- Pistols
- Machine Pistols
- UMP45
- PP90M1
- Model 1887
# Unlocked at level 50!

### **Path:**
```
.
├── ...
├── 📁 Call of Duty Modern Warfare 3
│   └── 📁 zone
|      └── 📁 <your game language>
|          └── 📜 patch_specialops.ff
└── ...
```

#
![image](https://github.com/user-attachments/assets/738e38f9-5bf4-4cd8-a67f-cf2a08cb06bb)
![image](https://github.com/user-attachments/assets/40e0b3f8-918b-4023-9e4f-978706918173)
![image (1)](https://github.com/user-attachments/assets/1ca0ad40-34bc-4a19-afb5-6226c4b2ed47)
